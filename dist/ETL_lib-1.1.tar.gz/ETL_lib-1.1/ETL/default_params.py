default_params = {
  'data_source': 'default',  # Once chosen, this must never be changed
  'excluded_raw_paths': ['inc-2019_09_01/MessagesLikes'],
  'tables': {}
}